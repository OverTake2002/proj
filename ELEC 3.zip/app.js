
const EMAILJS = {
  publicKey: "QGbXjKvvtcQHtAdd9",
  serviceId: "service_jivhuvu",
  templateId: "template_ks251br"
};

const emailReady = () => window.emailjs && !EMAILJS.publicKey.startsWith("QGbXjKvvtcQHtAdd9");
if (window.emailjs && emailReady()) {
  emailjs.init({ publicKey: EMAILJS.publicKey });
}


async function sendItemEmail(item, kind) {
  if (!item || !item.email || !emailReady()) return;

  const claimed = kind === "claimed";

  const subject = claimed
    ? `[BCP Lost & Found] Item Claimed & Released - ${item.ref}`
    : `[BCP Lost & Found] Official Report Receipt - ${item.ref}`;

  const opening = claimed
    ? "Good news! Your report has been officially marked as CLAIMED / RELEASED.\n\n"
    : "Thank you for your report. Here is your official receipt.\n\n";

  const closing = claimed
    ? "This transaction has been recorded in our campus system. If you believe this was marked in error, please visit the Student Affairs Office or reply to this email."
    : "Please present this receipt together with a valid BCP Student ID at the Security Office (Prefecture).";

  const message = opening +
    `Reference Number: ${item.ref}\n` +
    `Report Type: ${item.type === "lost" ? "Lost Item Report" : "Found Item Report"}\n` +
    `Item: ${item.title}\n` +
    `Category: ${catLabel(item.category)}\n` +
    `Location: ${item.location}\n` +
    `Date: ${item.date}\n` +
    `Description: ${item.description}\n` +
    `Status: ${claimed ? "Claimed / Released" : "Active / Under Custody"}\n\n` + 
    closing;

  const send = emailjs.send(EMAILJS.serviceId, EMAILJS.templateId, {
    to_email: item.email,
    to_name: item.reporterName,
    subject: subject,
    message: message,
    ref: item.ref,
    item_title: item.title,
    status: claimed ? "Claimed" : "Active"
  });

  const waitLimit = new Promise(res => setTimeout(res, 8000));
  try {
    await Promise.race([send, waitLimit]);
    console.log("Email sent successfully to:", item.email);
  } catch (e) {
    console.warn("Email sending failed or timed out:", e);
  }
}

const CATEGORIES = [
  { id: "ids", label: "Student IDs", icon: "🪪" },
  { id: "uniforms", label: "Uniforms", icon: "👕" },
  { id: "books", label: "Books / Modules", icon: "📚" },
  { id: "gadgets", label: "Gadgets", icon: "💻" },
  { id: "tumblers", label: "Tumblers / Umbrellas", icon: "☂️" },
  { id: "others", label: "Others", icon: "📦" }
];

const LOCATIONS = [
   "Gymnasium", "Canteen", "Library", 
  "Computer Laboratory", "Registrar's Office", "Covered Court", "Parking Area",
];

let items = [];
let adminPass = "";
const API = "/api/public/items";
const myReceipts = () => JSON.parse(localStorage.getItem("bcp_my_receipts") || "{}");

async function loadItems() {
  try {
    const res = await fetch(API, { headers: adminPass ? { "x-admin-pass": adminPass } : {} });
    if (!res.ok) throw new Error();
    items = await res.json();
    const mine = myReceipts();
    items = items.map(i => mine[i.id] ? { ...i, email: i.email || mine[i.id].email } : i);
  } catch (e) {
    console.error("Failed to load items:", e);
  }
}

let currentCategory = "all";
let currentType = "all";
let uploadedPhoto = "";

const PAGES = {
  home: "index.html",
  report: "report.html",
  receipts: "receipts.html",
  receipt: "receipts.html",
  admin: "admin.html",
  about: "about.html"
};

function navigate(viewName) {
  const target = document.getElementById(`view-${viewName}`);
  if (!target) {
    location.href = PAGES[viewName] || "index.html";
    return;
  }
  document.querySelectorAll(".page-view").forEach(el => el.classList.add("hidden"));
  target.classList.remove("hidden");
  window.scrollTo(0, 0);
  if (viewName === "home") renderItems();
  if (viewName === "receipts") renderReceiptList();
}

function initCategoriesAndLocations() {
  const catGrid = document.getElementById("categoryList");
  const catSelect = document.getElementById("itemCategory");
  const locSelect = document.getElementById("itemLocation");

  if (catGrid) catGrid.innerHTML = "";
  if (catSelect) catSelect.innerHTML = "<option value='' disabled selected>Select category...</option>";
  if (locSelect) locSelect.innerHTML = "<option value='' disabled selected>Select location...</option>";

  CATEGORIES.forEach(c => {
    if (catGrid) {
      catGrid.innerHTML += `
        <div class="cat-card" onclick="selectCategory('${c.id}', this)">
          <div style="font-size:20px;">${c.icon}</div>
          <div>${c.label}</div>
        </div>
      `;
    }
    if (catSelect) {
      catSelect.innerHTML += `<option value="${c.id}">${c.label}</option>`;
    }
  });

  LOCATIONS.forEach(l => {
    if (locSelect) {
      locSelect.innerHTML += `<option value="${l}">${l}</option>`;
    }
  });
}

function selectCategory(id, el) {
  if (currentCategory === id) {
    currentCategory = "all";
    el.classList.remove("active");
  } else {
    currentCategory = id;
    document.querySelectorAll(".cat-card").forEach(c => c.classList.remove("active"));
    el.classList.add("active");
  }
  renderItems();
}

function setFilter(type, el) {
  currentType = type;
  document.querySelectorAll(".tab-btn").forEach(b => b.classList.remove("active"));
  el.classList.add("active");
  renderItems();
}

function renderItems() {
  const searchInput = document.getElementById("searchInput");
  const query = searchInput ? searchInput.value.toLowerCase().trim() : "";
  const grid = document.getElementById("itemsGrid");
  if (!grid) return;
  grid.innerHTML = "";

  const activeCount = items.filter(i => i.status === "active").length;
  const claimedCount = items.filter(i => i.status === "claimed").length;
  
  const statActiveEl = document.getElementById("statActive");
  const statClaimedEl = document.getElementById("statClaimed");
  if (statActiveEl) statActiveEl.innerText = activeCount;
  if (statClaimedEl) statClaimedEl.innerText = claimedCount;

  const filtered = items.filter(i => {
    const matchCat = currentCategory === "all" || i.category === currentCategory;
    const matchType = currentType === "all" || i.type === currentType;
    const matchSearch = !query || 
      i.title.toLowerCase().includes(query) || 
      i.location.toLowerCase().includes(query) || 
      i.description.toLowerCase().includes(query);
    return i.status !== "pending" && matchCat && matchType && matchSearch;
  });

  if (filtered.length === 0) {
    grid.innerHTML = `<p style="grid-column: 1/-1; text-align:center; padding:30px; color:#64748b;">No items match your search.</p>`;
    return;
  }

  filtered.forEach(item => {
    const isClaimed = item.status === "claimed";
    const badgeText = isClaimed ? "Claimed" : (item.type === "lost" ? "Lost" : "Found");
    const badgeClass = isClaimed ? "badge-claimed" : (item.type === "lost" ? "badge-lost" : "badge-found");

    grid.innerHTML += `
      <div class="item-card" onclick="openItemDetails('${item.id}')">
        ${item.photo ? `<img src="${item.photo}" class="item-img" alt="${item.title}" />` : `<div class="item-img" style="display:flex;align-items:center;justify-content:center;font-size:40px;">📦</div>`}
        <div class="item-content">
          <span class="item-badge ${badgeClass}">${badgeText}</span>
          <div class="item-title">${item.title}</div>
          <div class="item-meta">📍 ${item.location} &bullet; 📅 ${item.date}</div>
        </div>
      </div>
    `;
  });
}

function openItemDetails(id) {
  const item = items.find(i => i.id === id);
  if (!item) return;

  const body = document.getElementById("modalBody");
  const isClaimed = item.status === "claimed";
  const badgeText = isClaimed ? "Claimed" : (item.type === "lost" ? "Lost Item" : "Found Item");
  const badgeClass = isClaimed ? "badge-claimed" : (item.type === "lost" ? "badge-lost" : "badge-found");

  body.innerHTML = `
    ${item.photo ? `<img src="${item.photo}" style="width:100%;height:180px;object-fit:cover;border-radius:10px;margin-bottom:12px;" alt="${item.title}" />` : ''}
    <span class="item-badge ${badgeClass}">${badgeText}</span>
    <h2 style="margin:8px 0;">${item.title}</h2>
    <p style="color:#64748b;font-size:14px;margin-bottom:14px;">${item.description}</p>
    <div style="background:#f8fafc;padding:12px;border-radius:8px;font-size:13px;line-height:1.7;">
      <div><strong>Category:</strong> ${catLabel(item.category)}</div>
      <div><strong>Location:</strong> ${item.location}</div>
      <div><strong>Date:</strong> ${item.date}</div>
      <div><strong>Reported By:</strong> ${item.reporterName}</div>
    </div>
    ${item.ref ? `<button class="btn btn-outline full-width" style="margin-top:12px;" onclick="closeModal();showReceipt('${item.id}')">🧾 View Official Receipt</button>` : ''}
    <div style="margin-top:12px;">
      <a href="tel:${item.contact}" class="btn btn-primary full-width" style="display:block;text-align:center;text-decoration:none;">📞 Contact: ${item.contact}</a>
    </div>
  `;
  document.getElementById("itemModal").classList.remove("hidden");
}

function closeModal() {
  document.getElementById("itemModal").classList.add("hidden");
}

function handlePhotoUpload(e) {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (event) => {
    uploadedPhoto = event.target.result;
    const preview = document.getElementById("photoPreview");
    preview.src = uploadedPhoto;
    preview.classList.remove("hidden");
    const box = document.getElementById("aiBox");
    if (box) box.classList.remove("hidden");
    const m = document.getElementById("aiMatches"); if (m) m.innerHTML = "";
    const s = document.getElementById("aiStatus"); if (s) s.innerText = "";
  };
  reader.readAsDataURL(file);
}

async function callAI(body) {
  const res = await fetch("/api/public/analyze", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || "error.");
  return data;
}

async function aiAutoTag() {
  if (!uploadedPhoto) return;
  const s = document.getElementById("aiStatus");
  s.innerText = "⏳ AI is reading the photo...";
  try {
    const r = await callAI({ action: "tag", photo: uploadedPhoto });
    document.getElementById("itemTitle").value = r.title;
    document.getElementById("itemCategory").value = r.category;
    document.getElementById("itemDesc").value = `${r.description} (Color: ${r.color})`;
    s.innerText = `✅ Detected: ${r.title} • ${catLabel(r.category)} • Color: ${r.color}. You can still edit.`;
  } catch (e) {
    s.innerText = "⚠️ " + e.message;
  }
}

async function aiFindMatches() {
  if (!uploadedPhoto) return;
  const s = document.getElementById("aiStatus");
  const box = document.getElementById("aiMatches");
  const type = document.querySelector('input[name="itemType"]:checked').value;
  s.innerText = `⏳ Searching for ${type === "lost" ? "found" : "lost"} items...`;
  box.innerHTML = "";
  try {
    const { matches } = await callAI({ action: "match", photo: uploadedPhoto, type });
    if (!matches.length) {
      s.innerText = "No matches found yet.";
      return;
    }
    s.innerText = `🎯 ${matches.length} possible matches:`;
    box.innerHTML = matches.map(m => `
      <div class="admin-item-row" style="gap:10px;">
        <img src="${m.photo}" style="width:56px;height:56px;object-fit:cover;border-radius:8px;" alt="" />
        <div style="flex:1;">
          <strong>${Math.round(m.score)}% match — ${m.title}</strong>
          <div style="font-size:11px;color:#64748b;">📍 ${m.location} &bullet; 📅 ${m.date}</div>
          <div style="font-size:12px;">${m.reason}</div>
        </div>
      </div>`).join("");
  } catch (e) {
    s.innerText = "⚠️ " + e.message;
  }
}


async function handleReportSubmit(e) {
  e.preventDefault();
  const form = e.target;
  const btn = form.querySelector('button[type="submit"]');
  btn.disabled = true;
  btn.innerText = "Submitting...";

  const payload = {
    type: document.querySelector('input[name="itemType"]:checked').value,
    title: document.getElementById("itemTitle").value,
    category: document.getElementById("itemCategory").value,
    location: document.getElementById("itemLocation").value,
    date: document.getElementById("itemDate").value,
    description: document.getElementById("itemDesc").value,
    reporterName: document.getElementById("reporterName").value,
    contact: document.getElementById("reporterContact").value,
    email: document.getElementById("reporterEmail") ? document.getElementById("reporterEmail").value : "",
    photo: uploadedPhoto || null
  };

  let newItem;
  try {
    const res = await fetch(API, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    if (!res.ok) {
      const responseText = await res.text();
      let detail = responseText;
      try {
        const responseData = JSON.parse(responseText);
        detail = responseData.message || responseData.error || responseText;
      } catch (_) {}
      throw new Error(`Server rejected the report (HTTP ${res.status})${detail ? `: ${detail}` : "."}`);
    }

    newItem = await res.json();
  } catch (error) {
    console.error("Report submission failed:", error);
    alert(error.message.includes("HTTP ")
      ? `Report was not submitted. ${error.message}`
      : "Could not connect to the report server. Check your connection and make sure the API is running, then try again.");
    return;
  } finally {
    btn.disabled = false;
    btn.innerText = "Submit Report & Generate Receipt";
  }

  const mine = myReceipts();
  mine[newItem.id] = { email: newItem.email || payload.email };
  localStorage.setItem("bcp_my_receipts", JSON.stringify(mine));
  items.unshift(newItem);
  await sendItemEmail(newItem, "receipt");

  form.reset();
  const preview = document.getElementById("photoPreview");
  if (preview) preview.classList.add("hidden");
  uploadedPhoto = "";
  showReceipt(newItem.id);
}

async function handleAdminLogin(e) {
  e.preventDefault();
  const pass = document.getElementById("adminPass").value.trim();
  try {
    const res = await fetch(API, {
      method: "PATCH",
      headers: { "Content-Type": "application/json", "x-admin-pass": pass },
      body: "{}"
    });
    if (res.status === 401) {
      alert("Incorrect passcode! Please try again.");
      return;
    }
    if (!res.ok) throw new Error(`Admin login failed (HTTP ${res.status}).`);
    adminPass = pass;
    await loadItems();
    document.getElementById("adminLoginCard").classList.add("hidden");
    document.getElementById("adminPanel").classList.remove("hidden");
    renderAdminList();
  } catch (error) {
    console.error(error);
    alert("Admin sign-in requires the server API to be available.");
  }
}

function adminLogout() {
  document.getElementById("adminLoginCard").classList.remove("hidden");
  document.getElementById("adminPanel").classList.add("hidden");
  document.getElementById("adminPass").value = "";
  adminPass = "";
  loadItems();
}

function renderAdminList() {
  const container = document.getElementById("adminItemsList");
  if (!container) return;
  container.innerHTML = "";

  if (items.length === 0) {
    container.innerHTML = `<p style="text-align:center;padding:20px;color:#64748b;">No listings available.</p>`;
    return;
  }

  items.forEach(item => {
    container.innerHTML += `
      <div class="admin-item-row">
        <div>
          <strong>${item.title}</strong>
          <div style="font-size:11px;color:#64748b;">📍 ${item.location} &bullet; Status: ${item.status.toUpperCase()} &bullet; Ref: ${item.ref || 'None'}</div>
        </div>
        <div class="admin-actions">
          ${item.ref ? `<button class="btn btn-outline" onclick="showReceipt('${item.id}')">Receipt</button>` : ''}
          ${item.status === 'active' ? `<button class="btn btn-outline" onclick="changeStatus('${item.id}', 'claimed')">Mark Claimed</button>` : ''}
          <button class="btn btn-outline" style="color:#ef4444;" onclick="deleteItem('${item.id}')">Delete</button>
        </div>
      </div>
    `;
  });
}

async function changeStatus(id, newStatus) {
  const res = await fetch(API, {
    method: "PATCH",
    headers: { "Content-Type": "application/json", "x-admin-pass": adminPass },
    body: JSON.stringify({ id, status: newStatus })
  });
  if (!res.ok) {
    alert("Update failed. Please try again.");
    return;
  }
  
  items = items.map(i => i.id === id ? { ...i, status: newStatus } : i);

  if (newStatus === "claimed") {
    const claimedItem = items.find(i => i.id === id);
    await sendItemEmail(claimedItem, "claimed");
  }

  renderAdminList();
}

async function deleteItem(id) {
  if (confirm("Are you sure you want to delete this listing permanently?")) {
    const res = await fetch(API + "?id=" + encodeURIComponent(id), {
      method: "DELETE",
      headers: { "x-admin-pass": adminPass }
    });
    if (!res.ok) {
      alert("Delete failed. Please try again.");
      return;
    }
    items = items.filter(i => i.id !== id);
    renderAdminList();
  }
}

function makeRef() {
  return "BCP-LF-" + Date.now().toString(36).toUpperCase().slice(-6);
}

function catLabel(id) {
  const c = CATEGORIES.find(c => c.id === id);
  return c ? c.label : id;
}

function showReceipt(id) {
  if (!document.getElementById("receiptBody")) {
    location.href = "receipts.html?id=" + encodeURIComponent(id);
    return;
  }
  const item = items.find(i => i.id === id);
  if (!item) return;
  const when = new Date(item.submittedAt || Number(item.id) || Date.now());

  document.getElementById("receiptBody").innerHTML = `
    <div class="receipt-head">
      <span class="badge-logo">BCP</span>
      <div>
        <small>Bestlink College of the Philippines</small>
        <h2>Official Lost & Found Receipt</h2>
      </div>
    </div>
    <div class="receipt-ref">
      <small>Reference Number</small>
      <strong>${item.ref || "—"}</strong>
    </div>
    ${item.photo ? `<img src="${item.photo}" class="receipt-photo" alt="${item.title}" />` : ""}
    <table class="receipt-table">
      <tr><td>Report Type</td><td>${item.type === "lost" ? "Lost Item Report" : "Found Item Report"}</td></tr>
      <tr><td>Item Name</td><td>${item.title}</td></tr>
      <tr><td>Category</td><td>${catLabel(item.category)}</td></tr>
      <tr><td>Campus Location</td><td>${item.location}</td></tr>
      <tr><td>Date Reported</td><td>${item.date}</td></tr>
      <tr><td>Description</td><td>${item.description}</td></tr>
      <tr><td>Reported By</td><td>${item.reporterName}</td></tr>
      <tr><td>Contact Details</td><td>${item.contact}</td></tr>
      ${item.email ? `<tr><td>Email (Gmail)</td><td>${item.email}</td></tr>` : ''}
      <tr><td>Status</td><td>${item.status === "claimed" ? "Claimed / Released" : "Active / Under Custody"}</td></tr>
      <tr><td>Submitted On</td><td>${when.toLocaleString("en-US", { dateStyle: "medium", timeStyle: "short" })}</td></tr>
    </table>
    <p class="receipt-note">Please present this receipt along with a valid BCP Student ID to the Security Office (MV Gate) or Student Affairs Office (MV Building) for verification, turnover, or claiming.</p>
  `;
  navigate("receipt");
}

function renderReceiptList() {
  const searchEl = document.getElementById("receiptSearch");
  const q = (searchEl ? searchEl.value : "").toLowerCase().trim();
  const list = document.getElementById("receiptList");
  if (!list) return;

  const withRef = items.filter(i => i.ref && (!q || i.ref.toLowerCase().includes(q) || i.title.toLowerCase().includes(q)));
  if (withRef.length === 0) {
    list.innerHTML = `<p style="text-align:center;padding:20px;color:#64748b;">No receipts found.</p>`;
    return;
  }
  list.innerHTML = withRef.map(i => `
    <div class="admin-item-row">
      <div>
        <strong>${i.ref}</strong>
        <div style="font-size:11px;color:#64748b;">${i.title} &bullet; ${i.date}</div>
      </div>
      <button class="btn btn-outline" onclick="showReceipt('${i.id}')">View Receipt</button>
    </div>`).join("");
}

window.onload = async () => {
  initCategoriesAndLocations();
  await loadItems();
  renderItems();
  renderReceiptList();
  const rid = new URLSearchParams(location.search).get("id");
  if (rid) showReceipt(rid);
};
